# Simple Prime Numer Checker
* You can use this simple Rust prime Number checker libary.


# How to use
* You Can use thi Library in your project with

> use RustPrimeNumberLibrary::IS_prime_OR_notPrime;

# Step1 

* calling function 

> IS_prime_OR_notPrime(int_num);

// And take one parameter andthis data type is u32
